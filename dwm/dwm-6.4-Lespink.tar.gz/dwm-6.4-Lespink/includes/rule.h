/* rules */
static const Rule rules[] = {
 /* xprop(1):
  * WM_CLASS(STRING) = instance, class
  * WM_NAME(STRING) = title
  */
 /* class      instance    title       tags mask     isfloating   monitor */
 { "Onboard",  NULL,       NULL,       0,            1,           -1 },
 { "xmessage", NULL,       NULL,       0,            1,           -1 },
};

