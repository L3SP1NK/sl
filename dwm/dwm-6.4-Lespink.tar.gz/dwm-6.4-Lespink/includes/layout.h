/* layout(s) */
static const float mfact        = 0.50; /* factor of master area size [0.05..0.95] */
static const int nmaster        = 1;    /* number of clients in master area */
static const int resizehints    = 1;    /* 1 means respect size hints in tiled resizals */
static const int lockfullscreen = 0;    /* 1 will force focus on the fullscreen window */

static const Layout layouts[] = {
 /* symbol     arrange function */
 { "==",  tile },    /* first entry is default */
 { "<>",  NULL },    /* no layout function means floating behavior */
 { " ",  monocle },
};

